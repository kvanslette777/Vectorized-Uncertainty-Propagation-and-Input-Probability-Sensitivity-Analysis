
import numpy as np
from scipy.stats import t as student
#from Model_Matrix import *
import matplotlib.pyplot as plt

# from gas_flow import gas_flow
# from magnetic_field import magnetic_field
# from ising import ising
# from precalculate import sample_model
from copy import deepcopy
import os
import json

import random
import time

import matplotlib.pyplot as plt




"""

The goal of this file is to allow the user to fool around with their model output probabilities. The output of a model is assumed to be given as well as the information from the model matrix.

First we will calculate:

1) Prob y binning
2) expectation value - for (single) random variable (y) and random field (y(x)) (i.e. matrix py)
3) Confidence interval calc - for random variable and random field (i.e. matrix py)
4) Probability source tracking - Bayes Rule p(x,alpha| y)= p(x,alpha)p(y|x,alpha)/p(y), note p(y|x,alpha) is a component of the model matrix
5) Determinisitic and probabilistic sensitivity analysis (coupled to source tracking)

And then introduce plotting for each.


Later this file will be modified to include data analysis and model verification tools.


 ******  probabilities and yset are assumed to be row numpy vectors of equal length  ***********

 ******  yset and p_y are calcuated before these functions are used

"""




"""
#1) expectation value f(y=yset)
"""

def expt(p_y,func_yset):

    if len(p_y.shape) > 1:
        if len(func_yset) == p_y.shape[1]:

            d=np.dot(p_y,func_yset)
        else:
            d=np.dot(p_y.T,func_yset)
    else:
        d=np.dot(p_y,func_yset)
    return d


    #because the std is so commonly used
def std_model(p_y,yset):
    sqravg=expt(p_y,yset**2)
    avgsqr=expt(p_y,yset)**2
    std=np.sqrt(sqravg-avgsqr)

    return std

"""
#2) Probability and Confidence levels ( Cls are probability, don't listen to the frequentist's)
"""

def prob_between_ab(p_y,yset,a,b):
    trans = 0
    if b<a:
        print('b should be greater than or equal to a')
        exit()
    if len(p_y.shape) > 1:
        if p_y.shape[0] == len(yset):
            p_y = p_y.T
            if np.round(np.sum(p_y[0]),1)!=1.0:
                print('142', np.round(np.sum(p_y[0]), 1))
                p_y = p_y.T
                trans = 1

                if np.round(np.sum(p_y[0]), 1) != 1.0:
                    print('149')
                    if p_y.shape[0]==p_y.shape[1]:
                        print('Error it is unclear if rows or columns denote probabilities as neither are normalized and the matrix is square')
                        exit()

        confint = np.zeros(p_y.shape[1])
        for i in range(p_y.shape[1]):
            if yset[i] >= a:
                if yset[i] <= b:
                    confint[i] = 1.0
        if trans==1:
            probs = np.dot(confint.T, p_y)


        else:
            probs = np.dot(p_y, confint)

    else:  #no matrix
        confint=np.zeros(p_y.shape[0])
        for i in range(p_y.shape[0]):
            if yset[i]>=a:
                if yset[i]<=b:
                    confint[i]=1.0
        probs=np.dot(p_y.T,confint)
    return probs

"""next"""

def conf_set(p_y,yset,alpha):  #alpha is 0<1-alpha<1 is the "confidence level"
    if len(p_y.shape) > 1:
        """
        if np.round(np.sum(p_y[0]), 1) != 1.0:
            print(np.round(np.sum(p_y[0]), 1))
            p_y = p_y.T
            if np.round(np.sum(p_y[0]), 1) != 1.0:
                print(np.round(np.sum(p_y[0]), 1))
                print('Error it is unclear if rows or columns denote probabilities as neither are normalized')
                exit()
        """
        values = [[0] for j in range(p_y.shape[0])]
        for j in range(p_y.shape[0]):
            for i in range(p_y.shape[1]):
                sum=0
                c=-1
                ind = np.argsort(p_y[j],kind='mergesort')
                while(sum<1-alpha):
                    sum=sum+p_y[j][ind[c]]
                    c=c-1
                values[j]=np.sort(yset[ind[c+1:]],kind='mergesort')
    else:
        ind = np.argsort(p_y)
        sum = 0
        c = -1
        while(sum < 1 - alpha) and p_y[ind[c+1]]>0.00001:
            sum = sum + p_y[ind[c]]
            c = c - 1
        values=np.sort(yset[ind[c+1:]],kind='mergesort')
    return values,sum # returns set of y values with largest probabilities having the property that their probability sum to >1-alpha


def maxprobvalues(p_y,yset):  #alpha is 0<1-alpha<1 is the "confidence level"
    if len(p_y.shape) > 1:
        """
        if np.round(np.sum(p_y[0]), 1) != 1.0:
            print(np.round(np.sum(p_y[0]), 1))
            p_y = p_y.T
            if np.round(np.sum(p_y[0]), 1) != 1.0:
                print(np.round(np.sum(p_y[0]), 1))
                print('Error it is unclear if rows or columns denote probabilities as neither are normalized')
                exit()
        """
        values = [[0] for j in range(p_y.shape[0])]
        for j in range(p_y.shape[0]):
            ind=np.argmax(p_y[j])
            allmaxind=[]
            for i in range(len(p_y[j])):
                if p_y[j][ind]==p_y[j][i]:
                    allmaxind=allmaxind+[i]
            values[j]=yset[allmaxind[int(len(allmaxind)/2)]]
    else:
        ind = np.argmax(p_y)
        allmaxind = []
        for i in range(len(p_y)):
            if p_y[ind] == p_y[i]:
                allmaxind = allmaxind + [i]
        values = yset[allmaxind[int(len(allmaxind) / 2)]]
    return values # returns set of y values with the largest probabilities



""" below is some commented code to get the minimum length confidence interval... turns out it takes forever to run.
The confidence set code above is way better anyways and produces equivilant results for single modal distributions (one hump). The above method makes sense for arbitrarily shaped distributions

def conf_int(p_y,yset,alpha):  #alpha is 0<1-alpha<1 is the "confidence level"
    cumulativetemp =0
    cumulativearray=np.array([0])
    for i in range(len(p_y)):
        cumulativetemp=cumulativetemp+p_y[i]
        cumulativearray=np.append(cumulativearray,cumulativetemp)
    probset=np.array([])
    for i in range(len(cumulativearray)):
        for j in range(i):
            diff=int(i-j)
            probset=np.append(probset,np.array([int(j),int(i),diff,cumulativearray[i]-cumulativearray[j]]))
    probset=probset.reshape(int(len(probset)/4),4)
    conf=1-alpha
    satisfies=np.array([])
    for i in range(probset.shape[0]):
        if probset[i][3]>=conf:
            satisfies=np.append(satisfies,probset[i])
    satisfies=satisfies.reshape(int(len(satisfies)/4),4)
    mindiffindex=np.argmin(np.array([satisfies[i][2] for i in range(satisfies.shape[0])]))
    return yset[int(satisfies[mindiffindex][0])],yset[int(satisfies[mindiffindex][1]-1)] # returns the narrowest interval having confidence level 1-alpha


"""

"""
#3) probability y binning
"""

def binprob_and_y(p_y,yset,N_bins):

    binwidthy=(yset[-1]-yset[0])/ N_bins
    count=0
    binupy=np.array([yset[0]+float((i+1)*binwidthy) for i in range(N_bins)])
    binnedy=binupy-float((binwidthy/2))*np.ones(len(binupy))
    binnedprob=np.zeros(N_bins)
    for i in range(len(yset)):
        if yset[i]<= binupy[count]:
            binnedprob[count]=binnedprob[count]+p_y[i]
        else:
            count=count+1
            binnedprob[count] = binnedprob[count] + p_y[i]


    return binnedprob, binnedy

"""Here we will make a binning matrix such that multiple p_y vectors of the same length can be binned simultaniously (i.e. p_y is a matrix)"""

def bin_matrix_prob_y(p_y,yset,N_bins):
    trans=0
    if len(p_y.shape)>1:
        if p_y.shape[1]==len(yset):
            p_y=p_y.T
            trans=1
    bin_mat=np.zeros((N_bins,len(yset)))
    binwidthy=(yset[-1]-yset[0])/ N_bins
    epsilon=binwidthy/10000000 #(to help round off durring binning)
    count=0
    binupy=np.array([yset[0]+float((i+1)*binwidthy) for i in range(N_bins)])
    binnedy=binupy-float((binwidthy/2))*np.ones(len(binupy))
    for i in range(len(yset)-1):
        if yset[i]<= binupy[count]+epsilon:
            bin_mat[count][i]=1
        else:
            count=count+1
            bin_mat[count][i] = 1
    if len(p_y.shape) > 1:
        if trans==1:
            p_y=p_y.T
            if bin_mat.shape[1]!=p_y.shape[0]:
                binnedprob=np.dot(bin_mat,p_y.T)

            else:
                binnedprob=np.dot(bin_mat,p_y)
        else:
            if bin_mat.shape[1] != p_y.shape[0]:
                binnedprob = np.dot(p_y.T, bin_mat)

            else:
                binnedprob = np.dot(bin_mat, p_y)

    return binnedprob, binnedy



""" 4) Bayes Rule and uncertain source tracking """

def prob_xalpha_given_any_y(model_mat,p_xa,p_y):  # p(x,alpha|y) = p(y|x,alpha)p(x,alpha)/p(y)
    # if len(p_xa.shape)>1:

    prob=np.multiply(model_mat,p_xa)
    print(prob)
    prob=np.true_divide(prob.T,p_y)
    return prob.T

def prob_xalpha_given_y(model_mat,p_xa,p_y,y):  # p(x,alpha|y) = p(y|x,alpha)p(x,alpha)/p(y)
    # if len(p_xa.shape)>1:

    prob=np.multiply(model_mat[y],p_xa)
    print(prob)
    prob=np.true_divide(prob.T,p_y[y])
    return prob.T

"""for a particular y, first upgrade using dictionaries"""
# def prob_xalpha_given_y(model_mat,p_xa,p_y,y,yset):  # p(x,alpha|y) = p(y|x,alpha)p(x,alpha)/p(y)
#
#     # if len(p_xa.shape)>1:
#
#     prob=np.multiply(model_mat,p_xa)
#     print(prob)
#     prob=np.true_divide(prob.T,p_y)
#     return prob.T

"""to be used in conjunction with above - first use above to find nonzero probability values, and then return set of posisble income values associated to them with their probabilities"""

# x1 = np.arange(9.0).reshape((3, 3))
# x2 = np.arange(3.0)
# # np.multiply(x1, x2)
# mul=np.multiply(x1, x2)
# print(x1,x2,mul)
# print(np.true_divide(mul, x2.T))
#



""" 5) Bayesian validation metric """


# def BVM_det(y_model,y_data,Boolean):

def BVM_nondet(mu_model, data_averages,data_points_vector_per_average, Boolean,Boolean_option):   ### this assumes the average value of the data is distributed according the student-t distribution and the model average output is known exactly to be mu_model
    scalevec=np.array([])
    for i in range(len(data_averages)):
        stemp=0
        for j in range(len(data_points_vector_per_average[i])):
            stemp=stemp+((data_points_vector_per_average[i][j]-data_averages[i])**2)/(len(data_points_vector_per_average[i])-1.0)
        scalevec=np.append(scalevec,np.array([stemp/np.sqrt(len(data_points_vector_per_average[i]))]))
    x=np.linspace(-5,5,100)

    tdist_peravg=np.array([])
    y=np.array([])
    for i in range(len(data_averages)):
        ytemp=(data_averages[i]-x)
        # ytemp=(data_averages[i]-x)/scalevec[i]

        # print(scalevec[i],ytemp)
        tdisttemp=np.array([student.pdf(x[j],len(data_points_vector_per_average[i])-1,0,scalevec[i]) for j in range(len(ytemp))])
        tdisttemp=tdisttemp/sum(tdisttemp)
        tdist_peravg=np.append(tdist_peravg,tdisttemp)
        y=np.append(y,[ytemp])
    y=y.reshape(len(data_averages),len(x))
    tdist_peravg=tdist_peravg.reshape(len(data_averages),len(x))
    print(tdist_peravg)

    BVMret=1.0
    for i in range(len(data_averages)):
        BVMrettemp=0.0
        for j in range(len(y[i])):
            BVMrettemp=BVMrettemp+Boolean(mu_model[i],y[i][j],Boolean_option)*tdist_peravg[i][j]
        BVMret=BVMret*BVMrettemp
    return BVMret

def Bool_mu(mu_model, mu_data, epsilon):
    if np.absolute(mu_model-mu_data)<= epsilon:
        ret=1.0
    else:
        ret=0.0

    return ret



# def Bool_y(y_model,y_data,epsilon):
#     # if len(y_model.shape) > 1:
#     #
#     # else:
#         ret=0.0
#
#
#
#     return d

#
# """testing stuff"""
# N=500
# data=np.array([[np.random.normal(10,4,N)],[np.random.normal(5,4,N)]])
# data=data.reshape(2,N)
# # print(data)
# dataavg=np.array([sum(data[i])/len(data[i]) for i in range(2)])
# print(dataavg)
# mumodel=np.array([10,5])
#
# works=BVM_nondet(mumodel, dataavg,data, Bool_mu,2)
#
# print('did it work?', works)
#
# scalevec=np.array([])
# for i in range(len(dataavg)):
#     stemp=0
#     for j in range(len(data[i])):
#         stemp=stemp+((data[i][j]-dataavg[i])**2)/(len(data[i])-1.0)
#     scalevec=np.append(scalevec,np.array([stemp/np.sqrt(len(data[i]))]))
#
# x=np.linspace(-5,5,100)
# tdist_peravg=np.array([])
# y=np.array([])
# for i in range(len(dataavg)):
#     ytemp=(dataavg[i]-x)
#     # ytemp=(data_averages[i]-x)/scalevec[i]
#
#     tdisttemp=np.array([student.pdf(x[j],len(data[i])-1,0,scalevec[i]) for j in range(len(ytemp))])
#     tdisttemp=tdisttemp/sum(tdisttemp)
#     tdist_peravg=np.append(tdist_peravg,tdisttemp)
#     y=np.append(y,[ytemp])
# y=y.reshape(len(dataavg),len(x))
# tdist_peravg=tdist_peravg.reshape(len(dataavg),len(x))
#     # print(tdist_peravg)
#
# plt.style.use('seaborn-darkgrid')
# palette = plt.get_cmap('Set1')
# string='Probablity of average from data: p(mu|Data, N=500)'
# plt.plot(y[0], tdist_peravg[0],marker='', color=palette(0), linewidth=1.8, alpha=0.9, label=string)
# ten=np.array([0.0 for i in range(len(y[0]))])
# ten[45]=0.1
# # print(y[0][50])
# plt.plot(y[0], ten, marker='', color=palette(1), linewidth=1.8, alpha=0.9,label='Probablity of average from model: p(mu|Model)')
# plt.legend(loc=2, ncol=1, fontsize='large')
#
#
# plt.title('Frequentist Model Validation: epsilon = 2')
# plt.xlabel('Mu')
# plt.ylabel('Probability mu')
# plt.show()
# """test area"""
# #
# #np.exp(-(i-(N-1)/2)**2/2)
# #
# #
# #
# #
# N=200
# option=1
# yset=np.linspace(1,5,N)
# py=np.asarray([np.exp(-(i-(N-1)/2)**2/2) for i in range(N)])
# py = py/(sum(py))
#
# # print(expt(py,yset),std_model(py,yset))
# #
# #
# # print('prob between',prob_between_ab(py,yset,-.001,np.inf))
# #
# # print('conf set',conf_set(py,yset,.1))
#
# w=binprob_and_y(py,yset,int(7))
# # print('binnedprobis',w)
# # print(py)
# py=np.append(py,py)
# py=py.reshape(2,len(yset))
# if option!=0:
#     py=py.T
# w=bin_matrix_prob_y(py,yset,int(7))
# # print(w)
# #
# # print(expt(py,yset),std_model(py,yset))
#
#
# # print('prob between',prob_between_ab(py,yset,-.001,np.inf))
# #
# # print('conf set',conf_set(py,yset,.1))
#
# w=bin_matrix_prob_y(py,yset,int(7))
# # print('binnedprobis',w)
#
# # py=w[0]
# # yset=w[1]
# # print(expt(py,yset),std_model(py,yset))
# #
# #
# # print('prob between',prob_between_ab(py,-.001,np.inf))
# #
# # print('conf set',conf_set(py,yset,.1))
# #
# # z=conf_int(py,yset,0.1)
# # print('min conf int',z)
# # w=binprob(py,yset,int(37))
# # print(w)
#
# #
# #
# # py=w[0]
# # yset=w[1]
# # print(expt(py,yset),std_model(py,yset))
# #
# #
# # print('prob between',prob_between_ab(py,-.001,np.inf))
# #
# # print('conf set',conf_set(py,yset,.1))
# #
# # z=conf_int(py,yset,0.1)
# # print('min conf int',z)
# # w=binprob(py,yset,int(10))
# # print(w)
# #
# #
# #
# # py=w[0]
# # yset=w[1]
# # print(expt(py,yset),std_model(py,yset))
#
#
# print('prob between',prob_between_ab(py,-.001,np.inf))
#
# print('conf set',conf_set(py,yset,.1))
#
# z=conf_int(py,yset,0.1)
# print('min conf int',z)
# w=binprob(py,yset,int(1))
# print(w)
#
#
#     #
#     # # data = np.array(data)
#     # length = coarseprobplot.shape[0]
#     # width = coarseprobplot.shape[1]
#     # mu, reduceyset = np.meshgrid(mu, reduceyset)
#     #
#     # fig = plt.figure()
#     # ax = fig.add_subplot(1, 1, 1, projection='3d')
#     # ax.plot_surface(mu, reduceyset, np.transpose(coarseprobplot))
#     # ax.set_xlabel('mu_x')
#     # ax.set_ylabel('y')
#     # ax.set_zlabel('p(y|m)')
#     #
#     # plt.show()
