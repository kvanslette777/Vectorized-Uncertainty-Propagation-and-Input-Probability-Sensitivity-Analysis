import numpy as np
import math
import time
from simplemodels import *
from scipy.special import erf
from scipy.sparse import csr_matrix as sparse_matrix


# makes an M by N matrix
def modelmatrix(modelfunction, x, alpha, fixed=None, vectorized = False, verbose = False):
    y=np.array([])
    w=0.0

    t1=time.time()
    counter, size = 0, len(alpha)*len(x)
    mod = 1 if size < 10 else int(0.1*size)
    if vectorized:
        x2, alpha2 = np.meshgrid(x, alpha)
        y = modelfunction(x2, alpha2, fixed)
        if type(y) == tuple and len(y) == 2:
            y, error = y
        else:
            error = 0*y
        y = y.flatten()
        y = np.round(y,10)
    else:
        for j in range(0,len(alpha)):
            ytemp = np.array([])
            error = []
            for i in range(0, len(x)):
                w, err = modelfunction(x[i], alpha[j], fixed)
                w = round(w,15)
                ytemp=np.append(ytemp,[w])
                error.append(err)
                counter += 1
                if verbose and counter%mod == 0:
                    print("Finished", counter, "out of", size )

            y=np.append(y,ytemp,axis=0)
        error = np.asarray(error)

    elapse1=time.time()-t1
    t2=time.time()
    yset, inv =np.unique(y, return_inverse = True)

    elapse2 = time.time() - t2
    M=len(yset)
    N=len(alpha)*len(x)

    t3 = time.time()
    I = np.arange(N)
    Delta = sparse_matrix((np.ones(N),(inv,I)),shape=(M,N))
    #Delta[inv,I] = 1.
    elapse3 = time.time() - t3
    #print(Delta)
    return [Delta,yset,elapse1,elapse2,elapse3,error]


"""
Here we generate the inverse model matrix using conditional probability. The inverse model matrix takes values equal to

p(x,alpha|y)= MM_value(y,(x,alpha))* p(x,alpha)/p(y).

The MM_value is the moodel matrix value for the y,x,alpha pairs.... right now for example these are the 1.0's.

The inverse model matrix can be used to propagate p(y) probability distributions, based on the situation p(x,alpha), backwards through the model.

That is we find M^-1 and we can calculate P'(x,alpha)=np.dot(M^{-1}[0],P'(y))
"""


def inverse_model_matrix(Model_Matrix,inputx_prob,outputy_prob):
    inverse_MM=sparse_matrix(Model_Matrix.transpose())
    xalphaind=inverse_MM.nonzero()[0]
    yind=inverse_MM.nonzero()[1]
    for i in range(len(inverse_MM.nonzero()[0])):
        inverse_MM.data[i]=inverse_MM.data[i]*inputx_prob[xalphaind[i]]/outputy_prob[yind[i]]
    return inverse_MM

""" proof of concept

Nx=5
Nalpha=5

#make uniform grid
x=np.linspace(-1.0,1.0,Nx)
alpha=np.linspace(-1.0,1.0,Nalpha)
M1=modelmatrix(modelZ,x,alpha,vectorized=True)

print('model matrix',M1[0])
probx=np.ones(len(x)*len(alpha))/(len(x)*len(alpha))
py=M1[0].dot(probx)
g=inverse_model_matrix(M1[0],probx,M1[0].dot(probx))

print('inverse example',g)
pxagain=g.dot(py)
print('is it an 'inverse' because Minv*M*p=p is',pxagain==probx)
"""
