"""Here we run IPSA using CPU VUP (GPU can be instatiated using the code from the JUQ_VUP_speedtests)"""
"""To use: simply run the script. It gives Nx propagated pdfs each with Nx*Nalpha number of samples"""

import pandas as pd
import numpy as np
from Inverse_Model_Matrix import *#includes Bayes rule
from analyze_pdf_functions import *
import random
import time


t8=time.time()



#### use less samples for testing
Nx=1000
Nalpha=1000


#make uniform grid
x=np.linspace(-5.0,5.0,Nx)
alpha=np.linspace(-1.0,1.0,Nalpha)

#input values with max probability (typically the mode or center of input pdfs)
xobs=x
alphaobs=np.zeros(1)#because gaussians are used


print('The total number of samples is',len(x)*len(alpha))#
Nmu=int(len(x)) #number of propagated distributions "L" from article

##MAKE sparse MODEL matrix
M1=modelmatrix(modelsens,x,alpha, vectorized=True)   #m1 = x^2 + alpha
print('Model 1 shape is',np.shape(M1[0]))





######### creating the probability in matrix for prob senitivity analysis/speedtest ############

def pinmat(Nmu):
    mu=x
    pinmat1=np.array([])
    pinmat1=np.array([probxalpha(mu[k]) for k in range(Nmu)])
    pinmat1=pinmat1.T
    return pinmat1


def probxalpha(mu):
    g=np.ones(len(x))
    g=mu*g
    f=np.kron(np.exp(-((alpha)**2.0)/(2.0*.25**2)),np.exp(-((x-g)**2.0)/(2.0*.5**2)))  ###The standard deviation for x is 0.5 here.
    f=f/np.sum(f)


    return f


############## CPU VUP ##################
tmm=time.time()
tmm2=time.time()
pin=pinmat(Nmu)

print('pin create time', time.time()-tmm2)

probsout=M1[0].dot(pin) ##propagates the probabilities!

print('matmul + create probability vectors time', time.time()-tmm)
print('total time: create model 1, pinmat, and propagate', time.time()-t8)
print('shape of output matrix',np.shape(probsout))



coarseprobplot, binnedy=bin_matrix_prob_y(probsout,M1[1],int(len(x)))
#coarse grained/binned for plotting purposes




print(np.shape(binnedy),'binnedy y shape')

coarseprobplot=coarseprobplot.transpose()

###initial estimation line
yg=modelsens(xobs,alphaobs,0)
yg = yg.flatten()
yg = np.round(yg,10)

###The coordinate transformation to the IPSA probability matrix is made by np.roll according to the amount given by yg###
coarseprobplotrolled=np.array([])
indyg=np.array([])
maxprob=coarseprobplot.max()

curshape=np.shape(coarseprobplot)
coarseprobplotcat=np.concatenate((np.zeros(curshape),np.concatenate((coarseprobplot,np.zeros(curshape)),axis=1)),axis=1)

for i in range(np.shape(coarseprobplotcat)[0]):
    indygtemp=(np.abs(binnedy-yg[i])).argmin()
    coarseprobplotrolledtemp=np.roll(coarseprobplotcat[i],(-indygtemp+int(len(binnedy)/2)))
    coarseprobplotrolled=np.append(coarseprobplotrolled,coarseprobplotrolledtemp)
    indyg=np.append(indyg,np.array([indygtemp]))

for i in range(np.shape(coarseprobplot)[1]):
    coarseprobplot[i][int(indyg[i])]=maxprob

mu,reduceyset= np.meshgrid(x,binnedy)
probmin,probmax=0.0,coarseprobplot.max()
coarseprobplot1=coarseprobplot.transpose()


fig,ax=plt.subplots()
c=ax.pcolormesh(mu,reduceyset,coarseprobplot1,cmap='inferno',vmin=probmin,vmax=probmax)
ax.set_ylabel('$y$ where $\sigma_a=0.25$')
ax.set_xlabel('observed value $\ell$ with $\sigma_{\ell}=3.0$')
ax.set_title('IPSA Probability Matrix Heatmap: $p(y|\ell,\sigma_{\ell},M)$')
ax.axis([mu.min(),mu.max(),reduceyset.min(),reduceyset.max()])
fig.colorbar(c,ax=ax)
plt.show()


fig,ax=plt.subplots()
reduceysetmid=binnedy-np.ones(len(binnedy))*((binnedy.max()+binnedy.min())/2)




#print(reduceyset,'upupupupuop')
min=reduceysetmid.min()
max=reduceysetmid.max()
diff=reduceysetmid[1]-reduceysetmid[0]
mincat=np.linspace(min-(max-min),min-diff,len(reduceysetmid))
maxcat=np.linspace(max+diff,(max-min)+max,len(reduceysetmid))
mixcat=np.concatenate((maxcat,mincat),axis=0)

reduceysetmid=np.concatenate((reduceysetmid,mixcat),axis=0)
reduceysetmid=np.unique(np.roll(reduceysetmid,len(reduceysetmid)))
coarseprobplot2=coarseprobplotrolled.reshape(np.shape(coarseprobplotcat))
#for i in range(np.shape(coarseprobplotcat)[0]):
#    coarseprobplot2[i][int(indyg[i])+int(1.5*len(binnedy))]=maxprob
coarseprobplot2=coarseprobplot2.transpose()
#reduceysetmid=np.append([reduceysetmid.min()-diff],reduceysetmid)
#reduceysetmid=np.append(reduceysetmid,[reduceysetmid.max()+diff])

mu,reduceysetmid=np.meshgrid(x,reduceysetmid)
c=ax.pcolormesh(mu,reduceysetmid,coarseprobplot2,cmap='inferno',vmin=probmin,vmax=probmax)
ax.set_ylabel('$\Delta y$ where $\sigma_a=0.25$')
ax.set_xlabel('observed value $\ell$ with $\sigma_{\ell}=3.0$')
ax.set_title('IPSA Probability Matrix Heatmap: $p(\Delta y|\ell,\sigma_{\ell},M)$')
ax.axis([mu.min(),mu.max(),mincat[int(len(mincat)/2)],maxcat[int(len(maxcat)/2)]])
fig.colorbar(c,ax=ax)
#ax.ylim(mincat[int(len(mincat)/2)],maxcat[int(len(maxncat)/2)])
plt.show()


exit()






"""spagetti statistic plots -- not fully vectorized so a bit slow for large Nx"""
#coarseprobplot2=coarseprobplot2.T

avg=expt(probsout,M1[1])

std=std_model(probsout,M1[1])


maxprobline=maxprobvalues(probsout.T,M1[1])



df=pd.DataFrame({'x':np.linspace(-5.0,5.0,len(avg)), '$< y(\ell) >$': avg, '$<y(\ell)>$ + $\sigma_{y(\ell) }$': avg+std, '$<y(\ell)>$ - $\sigma_{y(\ell) }$': avg-std,'maxprobarg($y(\ell)$)': maxprobline,'estimate $y(\ell)$': yg}) #'> 95% conf upper': conf_high_values, '> 95% conf lower': conf_low_values,'max probability line': maxprobline


# style
plt.style.use('seaborn-darkgrid')

# create a color palette
palette = plt.get_cmap('Set1')

# multiple line plot
num = 0
for column in df.drop('x', axis=1):
    num += 1
    if num==5:
        num=num+1
    plt.plot(df['x'], df[column], marker='', color=palette(num), linewidth=1.8, alpha=0.9, label=column)

# Add legend
plt.legend(loc=0, ncol=1, fontsize='large')

# Add titles
plt.title("IPSA expectation value curves: $p(y|\ell,\sigma_{\ell},M)$", loc='center', fontsize=14, fontweight=0, color='black')
plt.xlabel("observed value $\ell$ with $\sigma_{\ell}=0.5$")
plt.ylabel("$y$ where $\sigma_a=0.25$")



plt.show()




df=pd.DataFrame({'x':np.linspace(-5.0,5.0,len(avg)), '$< \Delta y(\ell) > $': avg-yg, '$<\Delta y(\ell)> +\sigma_{y(\ell) }$': avg+std-yg, '$<\Delta y(\ell)>  -\sigma_{y(\ell) }$': avg-std-yg,'maxprobarg($y(\ell)$) - $y(\ell)$': maxprobline-yg,'estimate $\Delta y(\ell)=0$ ': yg-yg}) #'> 95% conf upper': conf_high_values, '> 95% conf lower': conf_low_values,'max probability line': maxprobline


# style
plt.style.use('seaborn-darkgrid')

# create a color palette
palette = plt.get_cmap('Set1')

# multiple line plot
num = 0
for column in df.drop('x', axis=1):
    num += 1
    if num==5:
        num=num+1
    plt.plot(df['x'], df[column], marker='', color=palette(num), linewidth=1.8, alpha=0.9, label=column)

# Add legend
plt.legend(loc=0, ncol=1, fontsize='large')

# Add titles
plt.title("IPSA expectation value curves: $p(\Delta y|\ell,\sigma_{\ell},M)$", loc='center', fontsize=14, fontweight=0, color='black')
plt.xlabel("observed value $\ell$ with $\sigma_{\ell}=0.5$")
plt.ylabel("$\Delta y$ where $\sigma_a=0.25$")
plt.axis([mu.min(),mu.max(),-10,20])

plt.show()

exit()
