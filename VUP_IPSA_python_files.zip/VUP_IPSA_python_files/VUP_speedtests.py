"""To use: simply run the script. This file tests the time for MC, VUP CPU, and VUP GPU.
If no GPU is available, comment out the GPU section.
The MC section takes the longest to run by far... I suggest starting with low numbers of probabilities or commenting it out at first.
This file takes about 45 minuets -- 1 hour to run completely."""

import pandas as pd
import numpy as np
import numexpr as ne
from Model_Matrix_torch import *
from simplemodels import *
from analyze_pdf_functions import *

import random
import time
from scipy.interpolate import interp1d
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
import multiprocessing
from scipy.sparse import diags
import seaborn as sns

import torch
from mpl_toolkits.axes_grid.inset_locator import (inset_axes, InsetPosition, mark_inset)




numprobabilitydistributions= [1,1]+[i for i in range(2,51)]+[200,300,400,500,600,700,800,900,1000]
#fine grain for zoomed-in graph section
#the extra 1's are not double plotted but are there to "remove" GPU initialization time)

Nx=1000   #number of samples in x
Nalpha=1000   #number of samples in alpha
print('The total number of samples per distribution is',Nx*Nalpha)#


####### Python Function Definitions#######



def modelsins(x1,x2,fixed): #simple vectorizable sines model

    return 1.1*np.sin(x1)+7.0*np.sin(x2)**2

def pinmat(Nmu):  #creates probability in matrix with L=Nmu input probability vectors (NS)
    sigmas=np.linspace((np.pi/3)**2,np.pi**2,Nmu)
    pinmat1=[probxalpha(sigmas[k]) for k in range(Nmu)]
    pinmat1=np.array(pinmat1)
    pinmat1=pinmat1.T
    return pinmat1


def probxalpha(sigma):  #is a probability vector, (x,alpha) defined externally
    g=sigma**2
    f=np.kron(np.exp(-((alpha)**2.0)/(2.0*g)),np.exp(-((x)**2.0)/(2.0*g)))
    f=f/np.sum(f)

    return f

def modelmatrixspeed(modelfunction, x, alpha, fixed=None, vectorized = False):  ###model matrix code

    y=np.array([])
    w=0.0

    t1=time.time()
    counter, size = 0, len(alpha)*len(x)
    mod = 1 if size < 10 else int(0.1*size)
    if vectorized:
        x2, alpha2 = np.meshgrid(x, alpha)
        y = modelfunction(x2, alpha2,fixed)

        y = y.flatten()
        y = np.round(y,10)
    else: #else section not tested thoroughly because model assumed to be vectorizable
        for j in range(0,len(alpha)):
            ytemp = np.array([])
            error = []
            for i in range(0, len(x)):
                w, err = modelfunction(x[i], alpha[j], fixed)
                w = round(w,15)
                ytemp=np.append(ytemp,[w])
                error.append(err)
                counter += 1
                if verbose and counter%mod == 0:
                    print("Finished", counter, "out of", size )

            y=np.append(y,ytemp,axis=0)

    elapse1=time.time()-t1
    t2=time.time()
    yset, inv =np.unique(y, return_inverse = True)

    elapse2 = time.time() - t2
    M=len(yset)
    N=len(alpha)*len(x)

    t3 = time.time()

    I = np.arange(N)
    Delta = sparse_matrix((np.ones(N),(inv,I)),shape=(M,N)) #the sparse matrix
    #Delta[inv,I] = 1.
    elapse3 = time.time() - t3
    #print(Delta)
    return [Delta,yset,elapse1,elapse2,elapse3] #returns list,  [sparse model matix, unique y values, sample model time, unique sort time, create space matrix time]

def kronecker(t1, t2):  #for pytorch GPU
    """
    Computes the Kronecker product between two tensors.
    See https://en.wikipedia.org/wiki/Kronecker_product
    """
    t1_height, t1_width = t1.size()
    t2_height, t2_width = t2.size()
    out_height = t1_height * t2_height
    out_width = t1_width * t2_width

    return (
        t1.unsqueeze(2)
          .unsqueeze(3)
          .repeat(1, t2_height, t2_width, 1)
          .view(out_height, out_width)
    )*t2.repeat(t1_height, t1_width)
############## Starting speed test ##################
print('Running Speed Test....')
tottime=time.time()

"""############## MC probabilities ##################"""

fixed=0
MCtime=[]

for NS in numprobabilitydistributions:  #for number of
    timemmmc=time.time()
    sigmas=np.linspace((np.pi/3)**2,np.pi**2,NS)
    t1=time.time()

    for i in range(0,NS):  #propagate NS distributions
        mean=[0,0]
        cov=[[sigmas[i],0],[0,0.5]]
        x, alpha=np.random.multivariate_normal(mean,cov,Nx*Nalpha).T
        #x=np.random.normal(0,sigmas[i],Nx)
        #alpha=np.random.normal(0,.05,Nalpha)
        #x2, alpha2 = np.meshgrid(x, alpha)
        #y = modelsins(x2, alpha2,fixed)
        y = modelsins(x, alpha,fixed)
        y = y.flatten()
        y = np.round(y,10)
        y, counts = np.unique(y, return_counts=True) #this sorts and remembers counts such that they may be quickly binned into a histogram later
    MCtime.append(time.time()-timemmmc)
    print('time', time.time()-t1)




"""############## CPU VUP ##################"""


#pyout=sparse.csr_matrix.dot(M1[0],pinmat(Nmu))
i=-1
VUPCPUtime=[]


for NS in numprobabilitydistributions:

    #runtime.append([])
    time1 = time.time()
    #time2 = time.time()
    Nmu=NS
    probsout=0 #clearing up memory
    pin=0
    i = i+1


    #2D make uniform grid
    x=np.linspace(-1.0,1.0,Nx)
    alpha=np.linspace(-1.0,1.0,Nalpha) #later these are made into a meshgrid.


    ####MAKE MODEL MATRIX###
    M1=modelmatrixspeed(modelsins,x,alpha,vectorized=True) #M1[0] is sparse model matrix, M2[0] is set of output y's, the rest are computation times


    ######### creating the input probability matrix for speedtest ############

    pin=pinmat(NS)  #makes the input probability  matrix


    #propagate the probabilities and make output probability matrix
    probsout=M1[0].dot(pin)


    #### Additional matrix shape Information####
    #print('probin shape',np.shape(pin))
    #print('M1 shape',np.shape(M1[0]))
    #print('probout shape',np.shape(probsout))

    VUPCPUtime.append(time.time()-time1)
#clear memory
probsout=0
pin=0
M1[0]=0
M1[1]=0


"""############## GPU VUP ##################"""

VUPGPUtime=[]

for NS in numprobabilitydistributions:

    time1=time.time()

    x=np.linspace(-5.0,5.0,Nx)
    x=np.float32(x)

    alpha=np.linspace(-1.0,1.0,Nalpha)
    alpha=np.float32(alpha)

    timepin=time.time()

    x_mat=np.outer(x,np.ones(len(x)))
    x_mat=x_mat.T-x_mat    #this creates (x-mu) values for all x,mu pairs
    x_mat=np.float32(x_mat)
    #print('number of gigabytes of xmat', Nalpha*x_mat.nbytes/(10**9))

    alphatf = torch.from_numpy(np.array([alpha])).cuda()
    alphatf=torch.pow(alphatf,2.0)
    alphatf=torch.div(alphatf,-0.05)
    alphatf=torch.exp(alphatf)

    M1=modelmatrixtorch(modelsens,x,alpha, vectorized=True) #external

    #print('model matrix times',M1[2],M1[3],M1[4])
    batchnumber=1 #batches to mitigate GPU memory
    if NS>10:
        batchnumber=2
    #     print(batchnumber)
    #if NS>1000:
        #batchnumber=3
    #     print(batchnumber)
    #
    # if NS>2001:
    #     batchnumber=16
    #     print(batchnumber)
    # if NS>2501:
    #     batchnumber=40
    #     print(batchnumber)



    for i in range(batchnumber):
        xtf = torch.from_numpy(x_mat[:][int(i*NS/batchnumber):int((i+1)*NS/batchnumber)]).cuda()
        xtf=torch.pow(xtf,2.0)
        xtf=xtf.div(-0.1)
        xtf=torch.exp(xtf) #makes pdf
        pin=kronecker(alphatf,xtf).t()

        probsouttemp=torch.mm(M1[0],pin)  #propagates probabilities on GPU
        Z=torch.sum(probsouttemp, dim=0)
        probsouttemp=probsouttemp.div(Z)#normalizes
        probsouttemp=probsouttemp.cpu()
        probsouttemp=probsouttemp.numpy()
        if i==0:
            probsout=probsouttemp
        else:
            probsout=np.concatenate((probsout,probsouttemp),axis=1)

        del pin,probsouttemp,xtf,Z #frees memory
        torch.cuda.empty_cache()

    del probsout,M1[0]
    torch.cuda.empty_cache()

    VUPGPUtime.append(time.time()-time1)



print('Number of propagated distributions', numprobabilitydistributions)
print('MC time', MCtime)
print('VUP CPU time',VUPCPUtime)
print('VUP GPU time', VUPGPUtime)
print('Total run time', time.time()-tottime)
















#
#
#
# df=pd.DataFrame({'Number of distributions':numprobabilitydistributions[1:len(numprobabilitydistributions)], 'VUP run time': VUPtime, 'MC run time': MCtime[1:len(MCtime)],
# 'VUP GPU run time': VUPGPUtime[1:len(numprobabilitydistributions)]}) #'> 95% conf upper': conf_high_values, '> 95% conf lower': conf_low_values,'max probability line': maxprobline
#
# # style
# plt.style.use('seaborn-darkgrid')
#
# # create a color palette
# palette = plt.get_cmap('Set1')
# fig, ax1=plt.subplots()
# # multiple line plot
# num = 0
# for column in df.drop('Number of distributions', axis=1):
#     num += 1
#     if num==5:
#         num=num+1
#     ax1.plot(df['Number of distributions'], df[column], marker='', color=palette(num), linewidth=1.8, alpha=0.9, label=column)
#
# # Add legend
# ax1.legend(loc=0, ncol=1, fontsize='large')
#
# # Add titles
# ax1.set_title("$L$ propagated probabilities: VUP vs MC ", loc='center', fontsize=14, fontweight=0, color='black')
# ax1.set_xlabel("Number of propagated distributions")
# ax1.set_ylabel("Time")
#
#
# ax2 = plt.axes([0,0,1,1])
# # Manually set the position and relative size of the inset axes within ax1
# ip = InsetPosition(ax1, [0.15,.47,0.25,0.25])
# ax2.set_axes_locator(ip)
# # Mark the region corresponding to the inset axes on ax1 and draw lines
# # in grey linking the two axes.
# mark_inset(ax1, ax2, loc1=2, loc2=4, fc="none", ec='0.5')
#
# # The data: only display for low temperature in the inset figure.
# # Tmax = max(T_D)
# # ax2.plot(T[T<=Tmax], Cp[T<=Tmax], 'x', c='b', mew=2, alpha=0.8,
# #          label='Experiment')
# # # The Einstein fit (not very good at low T).
# # ax2.plot(T_E[T_E<=Tmax], CV_E[T_E<=Tmax], c='m', lw=2, alpha=0.5,
# #          label='Einstein model')
# # # The Debye fit.
# # ax2.plot(T_D, CV_D, c='r', lw=2, alpha=0.5, label='Debye model')
# # ax2.legend(loc=0)
#
# num = 0
# for column in df.drop('Number of distributions', axis=1):
#     num += 1
#     if num==5:
#         num=num+1
#     ax2.plot(df['Number of distributions'][0:24], df[column][0:24], marker='', color=palette(num), linewidth=1.8, alpha=0.9, label=column)
# ax2.set_facecolor('white')
# ax2.spines['bottom'].set_color('.5')
# ax2.spines['top'].set_color('.5')
# ax2.spines['right'].set_color('.5')
# ax2.spines['left'].set_color('.5')
#
# ax1.spines['bottom'].set_color('.5')
# ax1.spines['top'].set_color('.5')
# ax1.spines['right'].set_color('.5')
# ax1.spines['left'].set_color('.5')
# ax1.set_facecolor('white')
# ax1.grid(color='gray', linestyle='-.',linewidth=0.7)
# #ax2.set_xlabel("$L$")
# #ax2.set_ylabel("Time")
#
# plt.show()


exit()
