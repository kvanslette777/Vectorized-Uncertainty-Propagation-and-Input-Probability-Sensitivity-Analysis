import numpy as np


def model1(x,alpha):

    return x**2+alpha

    #return np.random.randn(1)
    # return alpha*10.0*x
    # return np.sin(5.0*x+1.0*alpha)
    # return np.sinc(5.0*x+1.0*alpha)
    #return np.sinc(5.0*x+1.0*alpha)*np.sin(5.0*x+1.0*alpha)*np.cos(5.0*x+1.0*alpha)

def modelZ(x,alpha,fixed):

    return x**2+.1*np.sin(25.0*x)+alpha,0

def modelsens(x,alpha,fixed):

    return 1.0*x**2+5.0*np.cos(3.0*x)+alpha

def modelsens2(y,yg,fixed):

    return (y)**2

def modelR(x,alpha,fixed):
    z=np.where(x>0,-(x+1)**2+1,-(x-1)**2+1)
    return z,0



def model2(x,alpha):

    alpha=0.0
    return np.cos(.1*x+0.5)
    #return 2*x


"""def model2(x,alpha):
    alpha=0.0

    # return alpha*x*x
    # return alpha*10.0*x
    # z=x**2
    # t=1.0/6.0
    # return np.sin(5.0*x+1.0*alpha)+z**t
    if np.random.normal()<0:
        k=1.0
    else:
        k=-1.0
    return k*(-np.sin(.1*np.abs(x+1.0)+1.0+1.0*alpha)+1.0)

"""

def modelstochastic(x,alpha):


    return x+alpha



def modelarwa(x1,x2,x3):


    return np.sin(x1)+7.0*np.sin(x2)**2+.1*(x3**4)*np.sin(x1)
